import org.junit.Test;
import static org.junit.Assert.*;

public class MessageTest {

    @Test
    public void testMessageLength_Success() {
        Message msg = new Message("+2712345678", "Hi, this is a short message");
        assertEquals("Message ready to send", msg.checkMessageLength());
    }

    @Test
    public void testMessageLength_Failure() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 251; i++) sb.append("a");
        Message msg = new Message("+2712345678", sb.toString());
        assertEquals("Message exceeds 250 characters by 1, please reduce size.", msg.checkMessageLength());
    }

    @Test
    public void testRecipient_Success() {
        Message msg = new Message("+27718633002", "Hello");
        assertEquals("Cell phone number successfully captured", msg.checkRecipientCell());
    }

    @Test
    public void testRecipient_Failure() {
        Message msg = new Message("0857595219", "Hello");
        assertEquals("Cell phone number is incorrectly formatted, please correct the number and try again", msg.checkRecipientCell());
    }

    @Test
    public void testMessageID_Success() {
        Message msg = new Message("+27718633002", "Test");
        assertTrue(msg.checkMessageID());
    }

    @Test
    public void testMessageHash_Correct() {
        Message msg = new Message("+27718633002", "Hi Team Thanks");
        String hash = msg.createMessageHash();
        assertTrue(hash.contains(":1:"));
    }
}